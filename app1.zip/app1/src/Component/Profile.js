import React from "react";
import { Component } from "react";
import { useSelector } from "react-redux";

function Profile () {

    const state = useSelector((state) => state.user.value);

    return (
        <div>
            <p>Email: {state.email}</p>
            <p>Name: {state.name}</p>
        </div>
    );
}

export default Profile;