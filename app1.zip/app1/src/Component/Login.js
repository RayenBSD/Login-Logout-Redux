import React from "react";
import { Component } from "react";
import { useDispatch } from "react-redux";
import { login, logout } from "../features/User";

function Login () {

    const dispatch = useDispatch();

    return (
        <div>
            <button onClick={() => dispatch(
                login ({
                    email: "12345@gmail.com",
                    name: "rynbsd"
                })
            )}>Login</button>
            <button onClick={() => dispatch(logout())}>Logout</button>
        </div>
    );
    
}

export default Login;