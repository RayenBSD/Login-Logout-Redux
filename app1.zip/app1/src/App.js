import React, { Component } from "react";

import Login from "./Component/Login";
import Profile from "./Component/Profile";

import { store } from "./Store";
import { Provider } from "react-redux";

class App extends Component {

  render () {
    return (
      <div className="main">
        <Provider 
          store={store}
        >
          <Profile />
          <Login />
        </Provider>
      </div>
    );
  }
}

export default App;